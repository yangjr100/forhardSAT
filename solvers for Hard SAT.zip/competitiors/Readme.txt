
The source codes of all the comparators  are downloaded from the SAT competition 2017, 2018 or 2019.

Although the comparators used are different from the original codes, we just changed the output format of the result.