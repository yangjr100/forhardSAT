elseif
------

Starts the elseif portion of an if block.

::

  elseif(expression)

See the if command.
