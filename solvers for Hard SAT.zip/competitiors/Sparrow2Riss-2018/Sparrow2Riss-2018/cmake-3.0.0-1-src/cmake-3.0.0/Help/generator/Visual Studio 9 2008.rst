Visual Studio 9 2008
--------------------

Generates Visual Studio 9 2008 project files.

It is possible to append a space followed by the platform name to
create project files for a specific target platform.  E.g.  "Visual
Studio 9 2008 Win64" will create project files for the x64 processor;
"Visual Studio 9 2008 IA64" for Itanium.
